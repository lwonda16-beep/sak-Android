# Upstream notice

This reconstruction references the feature set of dezem/SAK. Third-party native tools used by the original project have their own licenses and must be redistributed only under their applicable terms.

This source package intentionally does not redistribute Nintendo keys, game content, or the original Windows executables.
