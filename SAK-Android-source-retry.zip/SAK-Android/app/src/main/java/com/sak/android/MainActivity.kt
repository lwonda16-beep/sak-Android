package com.sak.android

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SakApp() }
    }
}

private data class ActionItem(
    val title: String,
    val subtitle: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val status: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SakApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var log by remember { mutableStateOf("请选择一个 NSP / XCI / NSZ / XCZ 文件") }
    var busy by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    val backend = remember { NativeBackend(context) }

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        pickedUri = uri
        uri?.let {
            runCatching { context.contentResolver.takePersistableUriPermission(it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            log = "已选择：$it"
        }
    }

    val keyPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                log = withContext(Dispatchers.IO) {
                    runCatching {
                        val dest = File(context.filesDir, "keys/prod.keys")
                        dest.parentFile?.mkdirs()
                        context.contentResolver.openInputStream(uri).use { input ->
                            requireNotNull(input)
                            dest.outputStream().use { input.copyTo(it) }
                        }
                        "prod.keys 已导入应用私有目录（${dest.length()} bytes）"
                    }.getOrElse { "导入失败：${it.message}" }
                }
                busy = false
            }
        }
    }

    val actions = listOf(
        ActionItem("校验文件", "计算 SHA-256，确认文件读取与完整性", Icons.Default.Verified, "可用"),
        ActionItem("分割文件", "按 4 GiB 分卷，适用于 FAT32 存储", Icons.Default.CallSplit, "可用"),
        ActionItem("合并分卷", "合并 SAK Android 生成的 part.xx", Icons.Default.Merge, "可用"),
        ActionItem("XCI → NSP", "需要 Android ARM64 版 4NXCI/hactool", Icons.Default.SwapHoriz, if (backend.isAvailable(NativeBackend.Tool.FOUR_NXCI)) "核心已安装" else "待安装核心"),
        ActionItem("NSP → NSZ", "需要 Android ARM64 NSZ 后端", Icons.Default.Compress, if (backend.isAvailable(NativeBackend.Tool.NSZ)) "核心已安装" else "待安装核心"),
        ActionItem("NSZ → NSP", "需要 Android ARM64 NSZ 后端", Icons.Default.Unarchive, if (backend.isAvailable(NativeBackend.Tool.NSZ)) "核心已安装" else "待安装核心"),
        ActionItem("XCI → XCZ", "需要 Android ARM64 NSZ 后端", Icons.Default.Archive, if (backend.isAvailable(NativeBackend.Tool.NSZ)) "核心已安装" else "待安装核心"),
        ActionItem("XCZ → XCI", "需要 Android ARM64 NSZ 后端", Icons.Default.Unarchive, if (backend.isAvailable(NativeBackend.Tool.NSZ)) "核心已安装" else "待安装核心")
    )

    MaterialTheme(colorScheme = dynamicColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column { Text("SAK Android"); Text("Switch Army Knife · Android 重构版", style = MaterialTheme.typography.labelSmall) } },
                    actions = {
                        IconButton(onClick = { showTools = true }) { Icon(Icons.Default.Build, "Native 核心") }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { filePicker.launch(arrayOf("*/*")) }) {
                    Icon(Icons.Default.FolderOpen, "选择文件")
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    ElevatedCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("当前文件", style = MaterialTheme.typography.titleMedium)
                            Text(pickedUri?.toString() ?: "尚未选择")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { filePicker.launch(arrayOf("*/*")) }) { Text("选择文件") }
                                OutlinedButton(onClick = { keyPicker.launch(arrayOf("text/plain", "*/*")) }) { Text("导入 prod.keys") }
                            }
                        }
                    }
                }
                items(actions) { action ->
                    ElevatedCard(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            when (action.title) {
                                "校验文件" -> pickedUri?.let { uri ->
                                    scope.launch {
                                        busy = true
                                        log = withContext(Dispatchers.IO) {
                                            runCatching { "SHA-256: ${FileOps.sha256(context.contentResolver, uri)}" }
                                                .getOrElse { "校验失败：${it.message}" }
                                        }
                                        busy = false
                                    }
                                } ?: run { log = "请先选择文件" }
                                "分割文件" -> pickedUri?.let { uri ->
                                    scope.launch {
                                        busy = true
                                        log = withContext(Dispatchers.IO) {
                                            runCatching {
                                                val dir = File(context.getExternalFilesDir(null), "split/${System.currentTimeMillis()}")
                                                val files = FileOps.splitFile(context.contentResolver, uri, dir, 4L * 1024 * 1024 * 1024 - 1024 * 1024)
                                                "分割完成：${files.size} 个分卷\n${dir.absolutePath}"
                                            }.getOrElse { "分割失败：${it.message}" }
                                        }
                                        busy = false
                                    }
                                } ?: run { log = "请先选择文件" }
                                else -> log = if (action.status == "可用") "该功能需要选择对应输入。" else "${action.title}：${action.status}。不会调用 Windows EXE。"
                            }
                        }
                    ) {
                        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            Icon(action.icon, null)
                            Column(Modifier.weight(1f)) {
                                Text(action.title, style = MaterialTheme.typography.titleMedium)
                                Text(action.subtitle, style = MaterialTheme.typography.bodyMedium)
                            }
                            AssistChip(onClick = {}, label = { Text(action.status) })
                        }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("任务日志", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))
                            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                            Spacer(Modifier.height(8.dp))
                            Text(log)
                        }
                    }
                }
            }
        }

        if (showTools) {
            AlertDialog(
                onDismissRequest = { showTools = false },
                confirmButton = { TextButton(onClick = { showTools = false }) { Text("关闭") } },
                title = { Text("Native ARM64 核心状态") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        NativeBackend.Tool.entries.forEach { tool ->
                            Text("${tool.fileName}: ${if (backend.isAvailable(tool)) "已安装" else "未安装"}")
                        }
                        Text("为避免伪功能，未安装真实 ARM64 核心时转换按钮只显示状态，不执行虚假转换。")
                    }
                }
            )
        }
    }
}

@Composable
private fun dynamicColorScheme(): ColorScheme {
    val context = androidx.compose.ui.platform.LocalContext.current
    return if (android.os.Build.VERSION.SDK_INT >= 31) {
        if (androidx.compose.foundation.isSystemInDarkTheme()) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else if (androidx.compose.foundation.isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
}
