package com.sak.android

import android.content.Context
import java.io.File

/**
 * Native backend contract for Android ARM64 tools.
 * The UI only enables an operation when its executable is present.
 * No Windows .exe is ever invoked.
 */
class NativeBackend(private val context: Context) {
    private val nativeDir: File get() = File(context.filesDir, "native")

    enum class Tool(val fileName: String) {
        HACTOOL("hactool"),
        FOUR_NXCI("4nxci"),
        NSZ("nsz"),
        HACTOOLNET("hactoolnet")
    }

    fun toolFile(tool: Tool) = File(nativeDir, tool.fileName)
    fun isAvailable(tool: Tool) = toolFile(tool).let { it.isFile && it.canExecute() }

    fun installTool(source: File, tool: Tool) {
        nativeDir.mkdirs()
        val dest = toolFile(tool)
        source.copyTo(dest, overwrite = true)
        check(dest.setExecutable(true, true)) { "无法设置 native 工具执行权限" }
    }

    fun run(tool: Tool, args: List<String>, workingDir: File = context.cacheDir): Result<String> {
        val binary = toolFile(tool)
        if (!isAvailable(tool)) return Result.failure(IllegalStateException("${tool.fileName} ARM64 核心未安装"))
        return runCatching {
            val p = ProcessBuilder(listOf(binary.absolutePath) + args)
                .directory(workingDir)
                .redirectErrorStream(true)
                .start()
            val text = p.inputStream.bufferedReader().readText()
            val code = p.waitFor()
            check(code == 0) { "${tool.fileName} 退出码 $code\n$text" }
            text
        }
    }
}
