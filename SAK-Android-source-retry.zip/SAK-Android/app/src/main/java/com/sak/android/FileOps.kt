package com.sak.android

import android.content.ContentResolver
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

object FileOps {
    fun sha256(resolver: ContentResolver, uri: Uri): String {
        val md = MessageDigest.getInstance("SHA-256")
        resolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "无法打开输入文件" }
            val buf = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n <= 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    fun splitFile(
        resolver: ContentResolver,
        uri: Uri,
        outputDir: File,
        partSize: Long,
        onProgress: (Long) -> Unit = {}
    ): List<File> {
        require(partSize > 0) { "分卷大小必须大于 0" }
        outputDir.mkdirs()
        val result = mutableListOf<File>()
        var part = 0
        var total = 0L
        resolver.openInputStream(uri).use { raw ->
            requireNotNull(raw) { "无法打开输入文件" }
            BufferedInputStream(raw, 1024 * 1024).use { input ->
                val buffer = ByteArray(1024 * 1024)
                while (true) {
                    val outFile = File(outputDir, String.format("part.%02d", part++))
                    var written = 0L
                    BufferedOutputStream(FileOutputStream(outFile), 1024 * 1024).use { out ->
                        while (written < partSize) {
                            val ask = minOf(buffer.size.toLong(), partSize - written).toInt()
                            val n = input.read(buffer, 0, ask)
                            if (n <= 0) break
                            out.write(buffer, 0, n)
                            written += n
                            total += n
                            onProgress(total)
                        }
                    }
                    if (written == 0L) {
                        outFile.delete()
                        break
                    }
                    result += outFile
                    if (written < partSize) break
                }
            }
        }
        return result
    }

    fun mergeFiles(parts: List<File>, output: File, onProgress: (Long) -> Unit = {}) {
        require(parts.isNotEmpty()) { "没有可合并的分卷" }
        output.parentFile?.mkdirs()
        var total = 0L
        BufferedOutputStream(FileOutputStream(output), 1024 * 1024).use { out ->
            val buffer = ByteArray(1024 * 1024)
            parts.sortedBy { it.name }.forEach { part ->
                BufferedInputStream(part.inputStream(), 1024 * 1024).use { input ->
                    while (true) {
                        val n = input.read(buffer)
                        if (n <= 0) break
                        out.write(buffer, 0, n)
                        total += n
                        onProgress(total)
                    }
                }
            }
        }
    }
}
