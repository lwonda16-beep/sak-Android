# SAK Android

Android-native reconstruction of dezem/SAK (Switch Army Knife).

## Current status

This is **not** a wrapper around the original Windows `SAK.exe`. The original project bundles Windows executables, so Android requires ARM64-native replacements.

Implemented in Kotlin:
- Android Storage Access Framework file picker
- Persistable read permission
- `prod.keys` import into app-private storage
- SHA-256 verification
- Large-file split into `part.00`, `part.01`, ...
- Merge engine for generated parts
- Material 3 / dynamic system color UI
- Native backend discovery and process runner
- Strict feature gating: conversion/compression operations are disabled until a real Android ARM64 core exists

Backend slots:
- `hactool`
- `4nxci`
- `nsz`
- `hactoolnet`

## Why the original EXEs are not bundled

The upstream SAK repo is Windows-oriented. Android cannot execute PE `.exe` programs directly. The correct port is to rebuild compatible source projects with Android NDK or replace them with libraries/portable implementations.

## Build

Requirements:
- JDK 17+
- Android SDK 35
- Android Studio Ladybug or newer (recommended)

Open the project in Android Studio and build `app`.

## Security / keys

No Nintendo keys are included. Import your own legally obtained `prod.keys`. The application stores them in its private app directory.

## Planned native integration

1. Cross-compile `hactool` with Android NDK for `arm64-v8a`.
2. Port or replace 4NXCI functionality with a portable implementation.
3. Integrate NSZ Python logic through a native/embedded approach or rewrite the needed compressor/decompressor path.
4. Add SAF output-directory selection so converted files can be written to arbitrary user-selected folders.
5. Add foreground service for long-running 10–100 GB jobs.
